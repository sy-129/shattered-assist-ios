/*
 * Pixel Dungeon
 * Copyright (C) 2012-2015 Oleg Dolya
 *
 * Shattered Pixel Dungeon
 * Copyright (C) 2014-2026 Evan Debenham
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.quest.vault;

import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Elemental;
import com.shatteredpixel.shatteredpixeldungeon.items.quest.DwarfToken;
import com.watabou.utils.Random;

public abstract class VaultElemental extends Elemental {

	public static Class<? extends Elemental> random(){
		float roll = Random.Float();
		if (roll < 0.4f){
			return Fire.class;
		} else if (roll < 0.8f){
			return Frost.class;
		} else {
			return Shock.class;
		}
	}

	public static class Fire extends FireElemental {

		{
			activateSteathGameplayBehaviour();

			//uses base elemental ACC and EVA

			maxLvl = 30;
			EXP = 0;
			loot = DwarfToken.class;
			lootChance = 1;
		}

	}

	public static class Frost extends FrostElemental {

		{
			activateSteathGameplayBehaviour();

			//uses base elemental ACC and EVA

			maxLvl = 30;
			EXP = 0;
			loot = DwarfToken.class;
			lootChance = 1;
		}

	}

	public static class Shock extends ShockElemental {

		{
			activateSteathGameplayBehaviour();

			//uses base elemental ACC and EVA

			maxLvl = 30;
			EXP = 0;
			loot = DwarfToken.class;
			lootChance = 1;
		}

	}
}
